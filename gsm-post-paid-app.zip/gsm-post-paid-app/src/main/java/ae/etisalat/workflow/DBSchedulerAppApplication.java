package ae.etisalat.workflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DBSchedulerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DBSchedulerAppApplication.class, args);
	}

}
