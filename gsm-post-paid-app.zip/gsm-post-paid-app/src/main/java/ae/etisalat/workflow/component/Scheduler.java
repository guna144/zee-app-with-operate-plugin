package ae.etisalat.workflow.component;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import ae.etisalat.workflow.db.DBConnection;
import io.zeebe.client.ZeebeClient;
import oracle.jdbc.OracleConnection;

@Component
public class Scheduler {

	Logger LOGGER = Logger.getLogger(SchedulerOld.class.getName());
	SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
	String sqlQuery = null;
	Date lastCheckedDate = new Date();
	List<String> instancesCreated = new ArrayList<>();

	@Scheduled(fixedRate=5000)
	public void trigger() throws SQLException {
		OracleConnection conn = DBConnection.connect_CBCMPD();
		PreparedStatement pstmt = null;
		
		String dateStrFrom =  sdf.format(lastCheckedDate.getTime() - 2000);
		String dateStrTo =  sdf.format(lastCheckedDate.getTime() + 3000);

	    sqlQuery = "select subrequest_id, status, created_date, modified_date from t_soh_subrequest "   	 		
	    		+"  where modified_date >  to_timestamp('" + dateStrFrom + "','YYYY-MM-DD HH24:MI:SS') "  
	    		+"  and   modified_date <= to_timestamp('" + dateStrTo   + "','YYYY-MM-DD HH24:MI:SS') " 
	    		+"  order by subrequest_id asc , modified_date desc";  
	    
	    
	    LOGGER.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Java cron job :: lastCheckedDate: " + sdf.format(lastCheckedDate) + "SQL QUERY :: "+sqlQuery);
	    try {
		     
	    	 pstmt = conn.prepareStatement(sqlQuery);
	    	 lastCheckedDate = new Date();
	    	 
	         ResultSet rs = pstmt.executeQuery();
	         while (rs.next()) {
	        	 
	        	 String subReqId = rs.getString("SUBREQUEST_ID");
	        	 String status = rs.getString("STATUS");
	        	 String createdDate = rs.getString("CREATED_DATE");
	        	 String modifiedDate = rs.getString("MODIFIED_DATE");
	        	 
	        	 LOGGER.info("SUBREQUEST ID: " + subReqId + " || STATUS: "+ status.toString() + " || CREATED_DATE: " + createdDate + " || MODIFIED_DATE: "+ modifiedDate);
 	 
	        	 if(!instancesCreated.contains(subReqId)) {
	        		 SubReq_Opened_Event(subReqId);
	        		 instancesCreated.add(subReqId); 
	        	 } 
	        	 
              	switch(status){ 
	                case "87": 
	                	SubReq_Opened_Event(subReqId);
	                    break; 
	                case "88": 
	                	SubReq_ToBeProcess_Event(subReqId);
	                    break; 
	                case "89": 
	                	SubReq_InProgress_Event(subReqId);
	                    break; 
	                case "90": 
	                	SubReq_Closed_Event(subReqId);
	                    break; 
	                default: 
	                	Raise_Incident_Event(subReqId);
	            }
 
	         }

	         rs.close();
	         pstmt.close();
	     }catch(SQLException ex){
	         if (conn != null){
	             conn.close();
	         }
	         throw ex;
	     }finally {
	    	 if (conn != null){
	             conn.close();
	         }
	     }
	}
	
	private void SubReq_Opened_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();

	        //System.out.println("Connected...... Status 87");
            client.newPublishMessageCommand()
            		.messageName("MSG_SUBREQ_OPENED")
            		.correlationKey("")
            		.variables("{\"KEY_SUBREQ_INPRO_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_COMS_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_CLOSED_ID\": "+subRequestId+","
            				+ " \"KEY_RAISE_INCIDENT\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_PROCESSING_ID\": "+subRequestId+","
            				+ " \"MSISDN\": "+123+","
            				+ " \"SERIAL1\": "+123+","
            				+ " \"REQUEST_ID\": "+subRequestId+","
    						+ " \"SUB_REQUEST_ID\": "+subRequestId+","
							+ " \"REQUEST_STATUS\": "+subRequestId+","
							+ " \"SUB_REQUEST_STATUS\": "+subRequestId+"}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
    }
    
    private void SubReq_ToBeProcess_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();

	        System.out.println("Connected....... Status 88");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_PROCESSING")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();


	        client.close();
	        System.out.println("Closed.");
    }

	private void SubReq_InProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 89");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_INPROGRESS")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void SubReq_ComsInProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 49464");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_COMS_INP")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	
	private void SubReq_Closed_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 90");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_CLOSED")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void Raise_Incident_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected....... Status others");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_RAISE_INCIDENT")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
//	        client.newFailCommand(2)
	
	        client.close();
	        System.out.println("Closed.");
	        
	        
	        
	}
}
