package ae.etisalat.workflow.component;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import ae.etisalat.workflow.common.DataModel;

import ae.etisalat.workflow.db.DBConnection;
import io.zeebe.client.ZeebeClient;
import oracle.jdbc.OracleConnection;

//@Component
public class SchedulerOld {

	Logger LOGGER = Logger.getLogger(Scheduler.class.getName());
	SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
	String sqlQuery = null;
	Date lastCheckedDate = new Date();
	DataModel data = null;
	List<DataModel> dataCollection = null;

	@Scheduled(fixedRate=5000)
	public void trigger() throws SQLException {
		OracleConnection conn = DBConnection.connect_CBCMPD();
		PreparedStatement pstmt = null;
		
		String dateStrFrom =  sdf.format(lastCheckedDate.getTime() - 2000);
		String dateStrTo =  sdf.format(lastCheckedDate.getTime() + 3000);
		
	    sqlQuery = " select * from t_soh_sub_request_audit "  
    	 		+"  where sub_request_id in (  select subrequest_id from t_soh_subrequest where modified_date > to_timestamp('" + dateStrFrom + "','YYYY-MM-DD HH24:MI:SS')) "    	 		
    	 		+"  and modified_date > to_timestamp('" + dateStrFrom + "','YYYY-MM-DD HH24:MI:SS') and modified_date <= to_timestamp('" + dateStrTo + "','YYYY-MM-DD HH24:MI:SS')"
    	 		+"  order by sub_request_id asc , modified_date desc ";
	    
	    sqlQuery = "select subrequest_id, status from t_soh_subrequest "   	 		
	    		+"  where modified_date >  to_timestamp('" + dateStrFrom + "','YYYY-MM-DD HH24:MI:SS') "  
	    		+"  and   modified_date <= to_timestamp('" + dateStrTo   + "','YYYY-MM-DD HH24:MI:SS') " 
	    		+"  order by subrequest_id asc , modified_date desc; ";  
	    
	    
	    LOGGER.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Java cron job :: lastCheckedDate: " + sdf.format(lastCheckedDate) + "SQL QUERY :: "+sqlQuery);
	    try {
		     
	    	 pstmt = conn.prepareStatement(sqlQuery);
//	    	 LOGGER.info("Before QUERY ======: "+pstmt.toString());
//	    	 pstmt.setTimestamp(1,new java.sql.Timestamp(lastCheckedDate.getTime()));
//	    	 pstmt.setTimestamp(2,new java.sql.Timestamp(lastCheckedDate.getTime()));
	    	 data = new DataModel();
	    	 lastCheckedDate = new Date();
	    	 dataCollection = new ArrayList<DataModel>();
	    	 
	    	 
	         ResultSet rs = pstmt.executeQuery();
	         while (rs.next()) {
	        	 LOGGER.info("SUBREQUEST ID ===== " + rs.getString("SUB_REQUEST_ID") + 
	        			 " || AUDIT_CODE ===== "+rs.getString("AUDIT_CODE") +
	        			 " || AUDIT_MESSAGE_1 ===== "+rs.getString("AUDIT_MESSAGE_1") +
	        			 " || CREATED_DATE ===== "+rs.getString("CREATED_DATE")
	        			 );
	        	 if(rs.getString("AUDIT_CODE").equals("REQUEST_AMEND_STARTED") 
	        			 || rs.getString("AUDIT_CODE").equals("SUBREQUEST_FINAL_SAVE")
	        			 || rs.getString("AUDIT_CODE").equals("INITIATE_SUBREQUEST")) {
	        		 
	        		 data.setSubRequestId(rs.getString("SUB_REQUEST_ID"));
		             data.setAuditCode(rs.getString("AUDIT_CODE"));
		             dataCollection.add(data);
		             System.out.println(dataCollection);
	        	 }
	         }
	         
	         
	         if(dataCollection != null && dataCollection.size() > 0) {
             	for(DataModel data : dataCollection){
             		System.out.println("Database Change Triggered");

                 	System.out.println("Start");
                     	String auditCode = data.getAuditCode();
                     	String subRequestId = data.getSubRequestId();
                     	
                     	switch(auditCode){ 
                             case "REQUEST_AMEND_STARTED": 
                             	SubReq_Opened_Event(subRequestId);
                                 break; 
                             case "SUBREQUEST_FINAL_SAVE": 
                             	SubReq_ToBeProcess_Event(subRequestId);
                                 break; 
                             case "INITIATE_SUBREQUEST": 
                             	SubReq_InProgress_Event(subRequestId);
                                 break; 
                             default: 
                             	Raise_Incident_Event();
                         }
                     	System.out.println("End");
             	}
         	}
	         
	         rs.close();
	         pstmt.close();
	     }catch(SQLException ex){
	         if (conn != null){
	             conn.close();
	         }
	         throw ex;
	     }finally {
	    	 if (conn != null){
	             conn.close();
	         }
	     }
	}
	
	
	private void SubReq_Opened_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected...... Status 87");
            client.newPublishMessageCommand()
            		.messageName("MSG_SUBREQ_OPENED")
            		.correlationKey("")
            		.variables("{\"KEY_SUBREQ_GENERATION_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_INPRO_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_COMS_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_CLOSED_ID\": "+subRequestId+","
            				+ " \"KEY_RAISE_INCIDENT\": "+subRequestId+"}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
    }
    
    private void SubReq_ToBeProcess_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected....... Status 88");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_PROCESSING")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();


	        client.close();
	        System.out.println("Closed.");
    }

	private void SubReq_InProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 89");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_INPROGRESS")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void SubReq_ComsInProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 49464");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_COMS_INP")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	
	private void SubReq_Closed_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 90");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_CLOSED")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void Raise_Incident_Event(){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected....... Status others");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_RAISE_INCIDENT")
		    		.correlationKey("input-1001") 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
//	        client.newFailCommand(2)
	
	        client.close();
	        System.out.println("Closed.");
	        
	        
	        
	}
}
