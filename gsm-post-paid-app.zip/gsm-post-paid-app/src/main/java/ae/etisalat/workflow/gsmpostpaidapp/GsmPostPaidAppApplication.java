package ae.etisalat.workflow.gsmpostpaidapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class GsmPostPaidAppApplication {

	public static void main(String[] args) {
//		SpringApplication.run(GsmPostPaidAppApplication.class, args);
	}

}
