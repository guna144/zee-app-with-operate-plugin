/**
 * 
 */
package ae.etisalat.workflow.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import ae.etisalat.workflow.common.DataModel;
import ae.etisalat.workflow.common.Constants;
import ae.etisalat.workflow.db.DBConnection;
import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.dcn.RowChangeDescription;

/**
 * @author gpalani
 *
 */
public class DBListener {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	
	

	public static void main(String[] args) throws SQLException {
		OracleConnection conn = null;
		DatabaseChangeRegistration dcr = null;
		try {
			conn = DBConnection.connect_CBCMPD();
			DBListener oracleDCN = new DBListener();
//			dcr = oracleDCN.run(conn);
			
			conn.unregisterDatabaseChangeNotification(dcr);
			System.out.println("Table unregistred 3");
			conn.close();
			System.out.println("Connection closed 3");
			
		} catch (Exception ex) {
			if (conn != null) {
				conn.unregisterDatabaseChangeNotification(dcr);
				System.out.println("Table unregistred 2");
				conn.close();
				System.out.println("Connection closed 2");
			}
			ex.printStackTrace();
		}
	}

	private DatabaseChangeRegistration run(OracleConnection p_conn) throws Exception {
		Properties prop = new Properties();
		prop.setProperty(OracleConnection.DCN_NOTIFY_ROWIDS, "true");
		DatabaseChangeRegistration dcr = p_conn.registerDatabaseChangeNotification(prop);
		//p_conn.unregisterDatabaseChangeNotification(dcr);
		System.out.println("Connection test...");
		try {
//			dcr.addListener(new DatabaseChangeListener() {
//
//				public void onDatabaseChangeNotification(DatabaseChangeEvent dce) {
//
//					/*
//					 * client .newCompleteCommand(job.getKey()) .variables(output1) .send() .join();
//					 */
//
//					RowChangeDescription[] rowsChanged = dce.getTableChangeDescription()[0].getRowChangeDescription();
//					String rowId = null;
//					List<DataModel> dataCollection = new ArrayList<DataModel>();
//					System.out.println("************************** DataBase operation done! ********************* "
//							+ rowsChanged.length);
//					int recordCount = rowsChanged.length;
//
//					for (RowChangeDescription row : rowsChanged) {
//
//						rowId = row.getRowid().stringValue();
//						System.out.println("Changed row id : " + rowId);
//						System.out.println("Row operation : " + row.getRowOperation().toString());
//
////						try {
////							PreparedStatement pstmt = conn.prepareStatement(Constants.QUERY_STATUS_CHECK_1);
////							((OracleStatement) pstmt).setDatabaseChangeRegistration(dcr);
////							DataModel data = new DataModel();
////
////							pstmt.setString(1, rowId);
////							ResultSet rs = pstmt.executeQuery();
////
////							while (rs.next()) {
////								data.setSubRequestId(rs.getString("SUBREQUEST_ID"));
////								data.setStatus(rs.getString("STATUS"));
////								dataCollection.add(data);
////							}
////
////							rs.close();
////							pstmt.close();
////						} catch (SQLException e) {
////							e.printStackTrace();
////						}
//
//						System.out.println("dataCollection >>>>>>>>>>> :" + dataCollection.toString());
//
//						if (dataCollection != null && dataCollection.size() == recordCount) {
//							for (DataModel data : dataCollection) {
//								System.out.println("Database Change Triggered");
//
//								System.out.println("Start");
//								String status = data.getStatus();
//								String subRequestId = data.getSubRequestId();
//
//								switch (status) {
//								case "87":
//									SubReq_Status_Check(subRequestId);
//									break;
//								/*
//								 * case "88": SubReq_ToBeProcess_Event(subRequestId); break; case "89":
//								 * SubReq_InProgress_Event(subRequestId); break; case "49464":
//								 * SubReq_ComsInProgress_Event(subRequestId); break; case "90":
//								 * SubReq_Closed_Event(subRequestId); break;
//								 */
//								default:
//									System.out.println("Default check....");
//								}
//								System.out.println("End");
//							}
//						}
//					} // for loop end
//				}
//			});

			Statement stmt = p_conn.createStatement();
			((OracleStatement) stmt).setDatabaseChangeRegistration(dcr);
			System.out.println("Statement created");
			ResultSet rs = stmt.executeQuery("select * from t_soh_subrequest where rownum=1");
			System.out.println("Statement query executed");
			while (rs.next()) {
				System.out.println("Statement query result");
			}
			System.out.println("Table registred");
			rs.close();
			stmt.close();
			p_conn.close();
		} catch (SQLException ex) {
			if (p_conn != null) {
				p_conn.unregisterDatabaseChangeNotification(dcr);
				System.out.println("Table unregistred 1");
				p_conn.close();
				System.out.println("Connection closed 1");
			}
			throw ex;
		}
		return dcr;
	}

	private void SubReq_Status_Check(String subRequestId) {

//	    	final ZeebeClient client = ZeebeClient.newClientBuilder()
//		            // change the contact point if needed
//		            .brokerContactPoint("GunaHP:26500")
//		            .build();
//
//		        System.out.println("Connected...... Status 87");
//	            client.newPublishMessageCommand()
//	            		.messageName("MSG_SUBREQ_OPENED")
//	            		.correlationKey("")
//	            		.variables("{\"output-1\": 3, \"output-2\": 4,"
//	            				+ " \"KEY_SUBREQ_PROCESSING_ID\": "+subRequestId+","
//	            				+ " \"KEY_SUBREQ_INPRO_ID\": "+subRequestId+","
//	            				+ " \"KEY_SUBREQ_COMS_ID\": "+subRequestId+","
//	            				+ " \"KEY_SUBREQ_CLOSED_ID\": "+subRequestId+","
//	            				+ " \"KEY_RAISE_INCIDENT\": "+subRequestId+"}")
//	            		.send()
//	            		.join();
//
//
//		        client.close();
//		        System.out.println("Closed.");

		ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(Constants.BROKER);

		try (ZeebeClient client = builder.build()) {

			System.out.println("Opening job worker");

			final JobWorker workerRegistration1 = client.newWorker().jobType("status-check")// (Constants.JOB_PROVISIONING_SYSTEM_CHECK)
					.handler(new GSM_JobHandler()).timeout(Duration.ofSeconds(10)).open();

		}
	}

	private static class GSM_JobHandler implements JobHandler {

		@Override
		public void handle(JobClient client, ActivatedJob job) {

			final Map<String, Object> inputVariables = job.getVariablesAsMap();
			final Map<String, Object> outputVariables = new HashMap<String, Object>();
			System.out.println(
					"inputVariables =================================================== : " + inputVariables.values());
			Integer input1 = (Integer) inputVariables.get("sub-request-id");
			Integer output1 = null;

			try {
				OracleConnection conn1 = DBConnection.connect_CBCMPD();
				PreparedStatement stmt = conn1.prepareStatement(Constants.QUERY_STATUS_CHECK);
				stmt.setInt(1, input1);
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					output1 = rs.getInt("STATUS");
					System.out.println("Status :: " + output1);
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}

			outputVariables.put("output1", output1);

			client.newCompleteCommand(job.getKey()).variables(outputVariables).send().join();
		}

	}

}
