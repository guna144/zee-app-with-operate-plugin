package ae.etisalat.workflow.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;

public class DBService {
	static String outPutParameter = null;
	static OracleConnection conn = null;
	static PreparedStatement pstmt = null;
	
	public static String execute(String query, String columnName, Integer inputParameter, Integer statusPatameter, Connection conn) {
		
		try {
			if(conn != null) {
				PreparedStatement pstmt = conn.prepareStatement(query);
				pstmt.setInt(1, inputParameter);
				if(statusPatameter != 0) pstmt.setInt(2, statusPatameter);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next()) {
					return outPutParameter = rs.getString(columnName);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}


}
