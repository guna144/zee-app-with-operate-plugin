/**
 * 
 */
package ae.etisalat.workflow.service;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.WorkflowInstanceEvent;

/**
 * @author Guna Palani
 *
 */
public class NewInstance {


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String RequestId = "477009034";
		String subRequestId = "621012345";
		String account_no = "568389120";
		String MSISDN = "971547058149";
		String SERIAL1 = "8997112101352329689";
		String request_Status = "489";
		String sub_Request_Status = "90";
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("DXB00087218:26500")
	            .build();

	        System.out.println("Connected.");
	        
            final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
                    .bpmnProcessId("GSM_Post_Paid_Process_Updated")
                    .latestVersion()
                    .variables("{\"SUB_REQUEST_ID\": "+subRequestId+", "
                    		+ "\"ACCOUNT_NO\": "+account_no+", "
                    		+ " \"MSISDN\": "+MSISDN+", "
            				+ " \"SERIAL1\": "+SERIAL1+", "
            				+ " \"REQUEST_ID\": "+RequestId+", "
							+ " \"REQUEST_STATUS\": "+request_Status+", "
							+ " \"SUB_REQUEST_STATUS\": "+sub_Request_Status+", "
							+ " \"KEY_RAISE_INCIDENT2\": "+subRequestId+" }")
                    .send()
                    .join();

            
            final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();

            System.out.println("Workflow instance created. Key: " + workflowInstanceKey);

	        client.close();
	        System.out.println("Closed.");
	}

}
