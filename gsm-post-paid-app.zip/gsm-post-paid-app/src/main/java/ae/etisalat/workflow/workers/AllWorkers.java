package ae.etisalat.workflow.workers;

import java.sql.SQLException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Logger;

import ae.etisalat.workflow.common.Constants;
import ae.etisalat.workflow.db.DBConnection;
import ae.etisalat.workflow.service.DBService;
import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;

public class AllWorkers {
	
	static Logger LOGGER = Logger.getLogger(AllWorkers.class.getName());

	public static void main(String[] args) {
		
		final ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(Constants.BROKER);
		
		try(ZeebeClient client = builder.build()){
			
			LOGGER.info("Opening job worker");
			
			LOGGER.info("Job Name :: "+client.getConfiguration().getDefaultJobWorkerName());
			
//			final JobWorker workRegistration0 = 
//					client.newWorker()
//					.jobType(Constants.JOB_STATUS_CHECK)
//					.handler(new WorkflowJobHandler(Constants.JOB_STATUS_CHECK))
//					.timeout(Duration.ofSeconds(10))
//					.open();
			
			final JobWorker workRegistration0 = 
					client.newWorker()
					.jobType("Sub_Process_Start")
					.handler(new WorkflowJobHandler(Constants.JOB_PROVISIONING_SYSTEM_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration1 = 
					client.newWorker()
					.jobType(Constants.JOB_PROVISIONING_SYSTEM_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_PROVISIONING_SYSTEM_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration2 = 
					client.newWorker()
					.jobType(Constants.JOB_LWM_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_LWM_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration3 = 
					client.newWorker()
					.jobType(Constants.JOB_RTF_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_RTF_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			
			final JobWorker workRegistration4 = 
					client.newWorker()
					.jobType(Constants.JOB_COMS_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_COMS_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			
//			final JobWorker workRegistration5 = 
//					client.newWorker()
//					.jobType(Constants.JOB_REQUEST_CREATION_CHECK)
//					.handler(new WorkflowJobHandler(Constants.JOB_REQUEST_CREATION_CHECK))
//					.timeout(Duration.ofSeconds(10))
//					.open();
//			
//			final JobWorker workRegistration6 = 
//					client.newWorker()
//					.jobType(Constants.JOB_SUB_REQUEST_CREATION_CHECK)
//					.handler(new WorkflowJobHandler(Constants.JOB_SUB_REQUEST_CREATION_CHECK))
//					.timeout(Duration.ofSeconds(10))
//					.open();
			
			final JobWorker workRegistration7 = 
					client.newWorker()
					.jobType(Constants.JOB_NETWORK_PROVISIONING_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_NETWORK_PROVISIONING_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration8 = 
					client.newWorker()
					.jobType(Constants.JOB_RESOURCE_ALLOCATION_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_RESOURCE_ALLOCATION_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration9 = 
					client.newWorker()
					.jobType(Constants.JOB_SR_REQUEST_CLOSURE_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_SR_REQUEST_CLOSURE_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration10 = 
					client.newWorker()
					.jobType(Constants.JOB_SR_SUB_REQUEST_CLOSURE_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_SR_SUB_REQUEST_CLOSURE_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
			final JobWorker workRegistration11 = 
					client.newWorker()
					.jobType(Constants.JOB_CBCM_BSCS_MESSAGE_CHECK)
					.handler(new WorkflowJobHandler(Constants.JOB_CBCM_BSCS_MESSAGE_CHECK))
					.timeout(Duration.ofSeconds(10))
					.open();
			
//			LOGGER.info("Worker Status : "+workRegistration.isOpen());
			waitUntilSystemInput("exit");
		}

	}
	
	private static class WorkflowJobHandler implements JobHandler {

		private String jobType = null;
		
		WorkflowJobHandler(String jobType){
			this.jobType = jobType;
		}
		@Override
		public void handle(JobClient client, ActivatedJob job) {
			 final Map<String, Object> inputVariables = job.getVariablesAsMap();
			    final Map<String, Object> outputVariables = new HashMap<>();
			    LOGGER.info("subrequest_id >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+inputVariables.values());
			    String result = null;
			    String columnName = "subrequest_id";
			    Integer statusParameter = 0;
			    Integer subrequest_id = (Integer) inputVariables.get("SUB_REQUEST_ID");
			    Integer account_no = (Integer) inputVariables.get("ACCOUNT_NO");
			    Integer MSISDN = (Integer) inputVariables.get("MSISDN");
			    Integer SERIAL1 = (Integer) inputVariables.get("SERIAL1");
			    Integer request_id = (Integer) inputVariables.get("REQUEST_ID");
			    
		    try {
		    	
		    	switch(jobType){ 
		    	
//			    	case Constants.JOB_STATUS_CHECK:
//				    	LOGGER.info("subrequest_id =============================================== ::"+subrequest_id);
//				    	columnName = "status";
//						result = DBService.execute(Constants.QUERY_STATUS_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
//						if(result == null) Raise_Incident_Event(subrequest_id);
//						LOGGER.info("Result =============================================== ::"+result);
//					    outputVariables.put("output1", result);
//					    DBConnection.connect_CBCMPD().close();
//					    	
//					    	client
//					        .newCompleteCommand(job.getKey())
//					        .variables(outputVariables)
//					        .send()
//					        .join();
//					    	break;
	
		    	case "Sub_Process_Start":
			    	columnName = "modified_user_id";	
					result = DBService.execute(Constants.QUERY_PROVISIONING_SYSTEM_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
					if(result == null) Raise_Incident_Event(subrequest_id);
				    outputVariables.put("output2", result);
				    DBConnection.connect_CBCMPD().close();
				    	client
				        .newCompleteCommand(job.getKey())
				        .variables(outputVariables)
				        .send()
				        .join();
				    	break;
				    	
			    	case Constants.JOB_PROVISIONING_SYSTEM_CHECK:
				    	columnName = "modified_user_id";	
						result = DBService.execute(Constants.QUERY_PROVISIONING_SYSTEM_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(subrequest_id);
					    outputVariables.put("output2", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
	
			    	case Constants.JOB_LWM_CHECK :
			    		columnName = "account_no";
						 result = DBService.execute(Constants.QUERY_LWM_CHECK, columnName, account_no, statusParameter, DBConnection.connect_CBCMPD());
						 if(result == null) Raise_Incident_Event(account_no);
					     outputVariables.put("output1", result);
					     DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_RTF_CHECK :
			    		columnName = "account_no";
						result = DBService.execute(Constants.QUERY_RTF_CHECK, columnName, account_no, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(account_no);
					    outputVariables.put("output1", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_SYSTEM_CHECK :
			    		columnName = "account_no";
						result = DBService.execute(Constants.QUERY_SYSTEM_CHECK, columnName, account_no, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(account_no);
					    outputVariables.put("output1", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
	
			    	case Constants.JOB_COMS_CHECK :
			    		columnName = "account_number";
						result = DBService.execute(Constants.QUERY_COMS_CHECK, columnName, account_no, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(account_no);
					    outputVariables.put("resultCount", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
//			    	case Constants.JOB_REQUEST_CREATION_CHECK :
//			    		columnName = "request_id";
//						result = DBService.execute(Constants.QUERY_REQUEST_CREATION_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
//						if(result == null) Raise_Incident_Event(subrequest_id);
//					    outputVariables.put("output1", result);
//					    DBConnection.connect_CBCMPD().close();
//					    	client
//					        .newCompleteCommand(job.getKey())
//					        .variables(outputVariables)
//					        .send()
//					        .join();
//					    	break;
//					    	
//			    	case Constants.JOB_SUB_REQUEST_CREATION_CHECK :
//						result = DBService.execute(Constants.QUERY_SUB_REQUEST_CREATION_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
//						if(result == null) Raise_Incident_Event(subrequest_id);
//					    outputVariables.put("output1", result);
//					    DBConnection.connect_CBCMPD().close();
//					    	client
//					        .newCompleteCommand(job.getKey())
//					        .variables(outputVariables)
//					        .send()
//					        .join();
//					    	break;
					    	
			    	case Constants.JOB_NETWORK_PROVISIONING_CHECK :
			    		columnName = "status";	
						result = DBService.execute(Constants.QUERY_NETWORK, columnName, subrequest_id, statusParameter, DBConnection.connect_COMSPD());
						if(result == null) Raise_Incident_Event(subrequest_id);
					    outputVariables.put("output1", result);
					    DBConnection.connect_COMSPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_RESOURCE_ALLOCATION_CHECK :
			    		columnName = "status";	
						result = DBService.execute(Constants.QUERY_RESOURCE_ALLOCATION_CHECK1, columnName, MSISDN, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(MSISDN);
						result = DBService.execute(Constants.QUERY_RESOURCE_ALLOCATION_CHECK2, columnName, SERIAL1, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(SERIAL1);						
					    outputVariables.put("output1", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_SR_REQUEST_CLOSURE_CHECK :
			    		columnName = "request_id";
			    		statusParameter = 489;
						result = DBService.execute(Constants.QUERY_SR_REQUEST_CLOSURE_CHECK, columnName, request_id, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(request_id);
					    outputVariables.put("output1", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_SR_SUB_REQUEST_CLOSURE_CHECK :
			    		statusParameter = 90;
						result = DBService.execute(Constants.QUERY_SR_SUB_REQUEST_CLOSURE_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
						if(result == null) Raise_Incident_Event(subrequest_id);
					    outputVariables.put("output1", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
					    	
			    	case Constants.JOB_CBCM_BSCS_MESSAGE_CHECK :
			    		columnName = "status";
						result = DBService.execute(Constants.QUERY_CBCM_BSCS_MESSAGE_CHECK, columnName, subrequest_id, statusParameter, DBConnection.connect_CBCMPD());
						if(!result.equals("PROCESSED")) Raise_Incident_Event(subrequest_id);
					    outputVariables.put("cbcm_output", result);
					    DBConnection.connect_CBCMPD().close();
					    	client
					        .newCompleteCommand(job.getKey())
					        .variables(outputVariables)
					        .send()
					        .join();
					    	break;
			    	default:
			    			Raise_Incident_Event(subrequest_id);
			    		
			    }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	private static void waitUntilSystemInput(final String exitCode) {
	    try (Scanner scanner = new Scanner(System.in)) {
	      while (scanner.hasNextLine()) {
	        final String nextLine = scanner.nextLine();
	        if (nextLine.contains(exitCode)) {
	          return;
	        }
	      }
	    }
	 }
	
	private static void Raise_Incident_Event(Integer subrequest_id){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            .brokerContactPoint(Constants.BROKER)
	            .build();
	
	        System.out.println("Connected....... Exception Stage");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_RAISE_INCIDENT")
		    		.correlationKey(String.valueOf(subrequest_id)) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	        client.close();
	        System.out.println("Closed.");
	        
	        
	        
	}

}
