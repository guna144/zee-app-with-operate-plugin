package ae.etisalat.workflow.workers;

import java.time.Duration;
import io.zeebe.client.ZeebeClient;

public class StatusCheck {

	
	String RequestId = "477009034";
	String subRequestId = "621012345";
	String account_no = "568389120";
	String MSISDN = "971547058149";
	String SERIAL1 = "8997112101352329689";
	String request_Status = "489";
	String sub_Request_Status = "90";

	public static void main(String[] args) {
		StatusCheck obj = new StatusCheck();
		obj.run(obj);
	}
	
	private void run(StatusCheck obj) {

		String subReqId = "621012345";
		String status = "87";
		for(int index = 0; index < 2; index++) {
			switch(status){ 
		        case "87": 
		        	obj.SubReq_Opened_Event(subReqId, obj);
		            break; 
		        case "88": 
		        	obj.SubReq_ToBeProcess_Event(subReqId, obj);
		            break; 
		        case "89": 
		        	obj.SubReq_InProgress_Event(subReqId, obj);
		            break; 
		        case "49464": 
		        	obj.SubReq_ComsInProgress_Event(subReqId, obj);
	                break;
		        case "90": 
		        	obj.SubReq_Closed_Event(subReqId, obj);
		        	obj.Sub_Process_Event_Start(subReqId, obj);
		            break; 
		        default: 
		        	obj.Raise_Incident_Event(subReqId, obj);
		  	}
			status = "90";
		}
		
	}

	
	private void SubReq_Opened_Event(String subRequestId, StatusCheck obj){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();

	        //System.out.println("Connected...... Status 87");
            client.newPublishMessageCommand()
            		.messageName("MSG_SUBREQ_OPENED")
            		.correlationKey("")
            		.variables("{\"KEY_SUBREQ_IN_PROGRESS_ID\": "+subRequestId+", "
            				+ " \"KEY_SUBREQ_COMS_ID\": "+subRequestId+", "
            				+ " \"KEY_SUBREQ_CLOSED_ID\": "+subRequestId+", "
            				+ " \"KEY_RAISE_INCIDENT1\": "+subRequestId+", "
            				+ " \"KEY_SUBREQ_PROCESSING_ID\": "+subRequestId+"}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
    }
    
    private void SubReq_ToBeProcess_Event(String subRequestId, StatusCheck obj){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();

	        System.out.println("Connected....... Status 88");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_PROCESSING")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();


	        client.close();
	        System.out.println("Closed.");
    }

	private void SubReq_InProgress_Event(String subRequestId, StatusCheck obj){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 89");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_IN_PROGRESS")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void SubReq_ComsInProgress_Event(String subRequestId, StatusCheck obj){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 49464");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_COMS_INP")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	
	private void SubReq_Closed_Event(String subRequestId, StatusCheck obj){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected...... Status 90");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_CLOSED")
		    		.correlationKey(subRequestId).variables("{\"SUB_REQUEST_ID\": "+subRequestId+"}") 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void Sub_Process_Event_Start(String subRequestId, StatusCheck obj){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
			System.out.println("Sub_Process_Event_Start >> subRequestId :: "+subRequestId);
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUB_PROCESS_START")
		    		.correlationKey(subRequestId) 
		    		.variables("{\"SUB_REQUEST_ID\": "+subRequestId+", "
            				+ " \"ACCOUNT_NO\": "+account_no+", "
            				+ " \"REQUEST_ID\": "+RequestId+", "
              				+ " \"MSISDN\": "+MSISDN+", "
            				+ " \"SERIAL1\": "+SERIAL1+", "
            				+ " \"REQUEST_STATUS\": "+request_Status+", "
            				+ " \"SUB_REQUEST_STATUS\": "+sub_Request_Status+"}")
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void Raise_Incident_Event(String subRequestId, StatusCheck obj){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("localhost:26500")
	            .build();
	
	        System.out.println("Connected....... Status others");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_RAISE_INCIDENT")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
//	        client.newFailCommand(2)
	
	        client.close();
	        System.out.println("Closed.");
	        
	        
	        
	}
}
