package ae.etisalat.workflow.workers;

import java.time.Duration;

import io.zeebe.client.ZeebeClient;

public class Test {

		String RequestId = "477009034";
		String subRequestId = "621012345";
		String account_no = "568389120";
		String MSISDN = "971547058149";
		String SERIAL1 = "8997112101352329689";
		String request_Status = "489";
		String sub_Request_Status = "90";

		public static void main(String[] args) {
			Test obj = new Test();
			obj.run(obj);
		}
		
		private void run(Test obj) {

			String subReqId = "621012345";
			String status = "90";
				switch(status){ 
			        case "90": 
			        	obj.Sub_Process_Event_Start(subReqId, obj);
			            break; 
			        default: 
			        	obj.Raise_Incident_Event(subReqId, obj);
			  	}
		}
			
		
		private void Sub_Process_Event_Start(String subRequestId, Test obj){
			
			final ZeebeClient client = ZeebeClient.newClientBuilder()
		            // change the contact point if needed
		            .brokerContactPoint("localhost:26500")
		            .build();
				System.out.println("Sub_Process_Event_Start >> subRequestId :: "+subRequestId);
		        client.newPublishMessageCommand()
			    		.messageName("MSG_SUB_PROCESS_START")
			    		.correlationKey(subRequestId) 
			    		.variables("{\"SUB_REQUEST_ID\": "+subRequestId+", "
	            				+ " \"ACCOUNT_NO\": "+account_no+", "
	            				+ " \"REQUEST_ID\": "+RequestId+", "
	              				+ " \"MSISDN\": "+MSISDN+", "
	            				+ " \"SERIAL1\": "+SERIAL1+", "
	            				+ " \"REQUEST_STATUS\": "+request_Status+", "
	            				+ " \"SUB_REQUEST_STATUS\": "+sub_Request_Status+"}")
			    		.timeToLive(Duration.ofMinutes(1))
			    		.send()
			    		.join();
		
		
		        client.close();
		        System.out.println("Closed.");
		}
		
		private void Raise_Incident_Event(String subRequestId, Test obj){
			
			final ZeebeClient client = ZeebeClient.newClientBuilder()
		            // change the contact point if needed
		            .brokerContactPoint("localhost:26500")
		            .build();
		
		        System.out.println("Connected....... Status others");
		        client.newPublishMessageCommand()
			    		.messageName("MSG_RAISE_INCIDENT")
			    		.correlationKey(subRequestId) 
			    		.timeToLive(Duration.ofMinutes(1))
			    		.send()
			    		.join();
		
//		        client.newFailCommand(2)
		
		        client.close();
		        System.out.println("Closed.");
		        
		        
		        
		}

}
