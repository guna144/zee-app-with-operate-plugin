package com.technocratsid.elasticsearch.plugin;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.logging.Logger;
import org.elasticsearch.cluster.metadata.IndexNameExpressionResolver;
import org.elasticsearch.cluster.node.DiscoveryNodes;
import org.elasticsearch.common.bytes.BytesReference;
import org.elasticsearch.common.settings.ClusterSettings;
import org.elasticsearch.common.settings.IndexScopedSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.settings.SettingsFilter;
import org.elasticsearch.common.util.concurrent.ThreadContext;
import org.elasticsearch.common.xcontent.XContentHelper;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.plugins.ActionPlugin;
import org.elasticsearch.plugins.Plugin;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestHandler;
import org.elasticsearch.rest.RestRequest.Method;
import org.elasticsearch.transport.netty4.Netty4Utils;
import org.json.JSONException;
import org.json.JSONObject;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

public class HelloWorldPlugin extends Plugin implements ActionPlugin {
	
	public static final Logger logger = Logger.getLogger(HelloWorldPlugin.class.getName());
	
	public List<RestHandler> getRestHandlers(final Settings settings,
	                                         final RestController restController,
	                                         final ClusterSettings clusterSettings,
	                                         final IndexScopedSettings indexScopedSettings,
	                                         final SettingsFilter settingsFilter,
	                                         final IndexNameExpressionResolver indexNameExpressionResolver,
	                                         final Supplier<DiscoveryNodes> nodesInCluster) {
		
		
	        return Collections.singletonList(new HelloWorldRestAction(settings, restController));
	    }

	
	
	
	public UnaryOperator<RestHandler> getRestHandlerWrapper(ThreadContext threadContext) {
	          return originalHandler -> (RestHandler) (request, channel, client) -> {
	        	logger.info("************** START **********************");
	        	logger.info("\n#############################\n METHOD ::::::: "+request.method());
	        	logger.info("\n#############################\n URI ::::::: "+request.uri());
//	        	logger.info("add customize uri :::::::================================= "+request.getHeaders().values());
//	            for (Map.Entry<String, String> entry : request.params().entrySet()) {
//	        		System.out.println("Param Key & Value >>>> : " + entry.getKey() + "======" + entry.getValue());
//	        	}
	        	
	        	   if (request.content().length() > 1) {
		        	   logger.info("getLocalAddress =================::: "+request.getLocalAddress());
		        	   logger.info("getRemoteAddress ================::: "+request.getRemoteAddress());
	        	   }
	            
	            RestRequestWrapper request1 = new RestRequestWrapper(request);
	            
	           if (filter(request1)) {
//	        	   logger.info("\n#############################\n     CONTENT EXIST, LENGTH: "+request.content().length() + "\n#############################\n");
	        	   BytesReference byteContentOld = request1.getContent();
	        	   logger.info("byteContentOld ::: "+byteContentOld);
	        	
	        	   String query = XContentHelper.convertToJson(byteContentOld, false, XContentType.JSON);
		           
		           ////////////////////////////////////////////////////////////////////////////////////////////
			        String varName = "input1";
			   		String varValue = "5";
			   		String input = query;
			   		String additionalFilter = "{\"has_child\":{\"query\":{\"bool\":{\"must\":[{\"term\":{\"varName\":{\"value\":\""+ varName +"\",\"boost\":1.0}}},{\"term\":{\"varValue\":{\"value\":\""+ varValue +"\",\"boost\":1.0}}}],\"adjust_pure_negative\":true,\"boost\":1.0}},\"type\":\"variable\",\"score_mode\":\"none\",\"min_children\":0,\"max_children\":2147483647,\"ignore_unmapped\":false,\"boost\":1.0}}";
			   		
			   		String additionalFilter2 = "{\"bool\":{\"adjust_pure_negative\":true,\"must\":[{\"has_child\":{\"min_children\":0,\"score_mode\":\"none\",\"query\":{\"exists\":{\"field\":\"incidentKey\",\"boost\":1}},\"boost\":1,\"type\":\"activity\",\"max_children\":2147483647,\"ignore_unmapped\":false}},{\"has_child\":{\"query\":{\"bool\":{\"must\":[{\"term\":{\"varName\":{\"value\":\""+varName+"\",\"boost\":1.0}}},{\"term\":{\"+varValue\":{\"value\":\""+varValue+"\",\"boost\":1.0}}}],\"adjust_pure_negative\":true,\"boost\":1.0}},\"type\":\"variable\",\"score_mode\":\"none\",\"min_children\":0,\"max_children\":2147483647,\"ignore_unmapped\":false,\"boost\":1.0}}],\"boost\":1}}";
//			   		
			   		JSONObject jsonObject = null;
		
			   		try {
			   		     jsonObject = new JSONObject(input);
	
			   		    	 if(jsonObject.has("query"))
			   			    	 if(jsonObject.getJSONObject("query").has("constant_score"))
			   			    		 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").has("filter"))
			   			    			 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").has("bool"))
			   			    				 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").getJSONObject("bool").has("must")){
			   			    				 JSONObject jsonNode =  jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").getJSONObject("bool");
			   			    				 JSONObject jsonFilterObject = new JSONObject(additionalFilter);
			   			    				 jsonNode.append("must", jsonFilterObject);
			   			    			 }
			   		    	 
			   		    	 
			   		    	 if(jsonObject.has("query"))
			   			    	 if(jsonObject.getJSONObject("query").has("bool"))
			   			    		 if(jsonObject.getJSONObject("query").getJSONObject("bool").has("must")){
			   			    				 JSONObject jsonNode =  jsonObject.getJSONObject("query").getJSONObject("bool");
			   			    				 JSONObject jsonFilterObject = new JSONObject(additionalFilter);
			   			    				 jsonNode.append("must", jsonFilterObject);
			   			    			 } 
			   		    	 
			   		    	/* if(jsonObject.has("query"))
			   		    		 if(jsonObject.getJSONObject("query").has("has_child")){
			   		    			 logger.info("jsonObject :: BEFORE :: "+jsonObject.toString());
			   		    			 JSONObject jsonNode =  jsonObject.getJSONObject("query");
			   		    			 jsonNode.remove("has_child");
			   		    			 logger.info("jsonObject :: AFTER <<<<<<< :: "+jsonObject.toString());
			   		    	 		 JSONObject jsonFilterObject = new JSONObject(additionalFilter2);
			   		    	 		 jsonObject.append("query", jsonFilterObject);
			   		    	 		 
			   		    	 		 logger.info("jsonNode :: AFTER >>>>>>>>> :: "+jsonObject.toString());
			   		    		 }*/
			   		    	 
			   		    	 
			   		    	
			   		    
			   		    	 
			   		
			   		}catch (JSONException err){
			   			System.out.println("Error :: "+err.toString());
			   		}
	
			   		query = jsonObject.toString();
			   		
		           ////////////////////////////////////////////////////////////////////////////////////////////
			   		
			   		String orig = "{\"size\":0,\"query\":{\"has_child\":{\"min_children\":0,\"score_mode\":\"none\",\"query\":{\"exists\":{\"field\":\"incidentKey\",\"boost\":1}},\"boost\":1,\"type\":\"activity\",\"max_children\":2147483647,\"ignore_unmapped\":false}},\"aggregations\":{\"activities\":{\"children\":{\"type\":\"activity\"},\"aggregations\":{\"incident_activities\":{\"filter\":{\"exists\":{\"field\":\"incidentKey\",\"boost\":1}},\"aggregations\":{\"errorMessages\":{\"terms\":{\"shard_min_doc_count\":0,\"field\":\"errorMessage\",\"size\":10000,\"show_term_doc_count_error\":false,\"min_doc_count\":1,\"order\":[{\"_count\":\"desc\"},{\"_key\":\"asc\"}]},\"aggregations\":{\"activity_to_instances\":{\"parent\":{\"type\":\"activity\"},\"aggregations\":{\"workflowIds\":{\"terms\":{\"shard_min_doc_count\":0,\"field\":\"workflowId\",\"size\":10000,\"show_term_doc_count_error\":false,\"min_doc_count\":1,\"order\":[{\"_count\":\"desc\"},{\"_key\":\"asc\"}]}}}}}}}}}}}}";
			   		JSONObject obj1 = new JSONObject(orig);
			   		 
			   		String query2 = "{\"query\":{\"constant_score\":{\"filter\":{\"bool\":{\"adjust_pure_negative\":true,\"must\":[{\"has_child\":{\"min_children\":0,\"score_mode\":\"none\",\"query\":{\"exists\":{\"field\":\"incidentKey\",\"boost\":1}},\"boost\":1,\"type\":\"activity\",\"max_children\":2147483647,\"ignore_unmapped\":false}},{\"has_child\":{\"min_children\":0,\"score_mode\":\"none\",\"query\":{\"bool\":{\"adjust_pure_negative\":true,\"must\":[{\"term\":{\"varName\":{\"boost\":1,\"value\":\"input1\"}}},{\"term\":{\"varValue\":{\"boost\":1,\"value\":\"5\"}}}],\"boost\":1}},\"boost\":1,\"type\":\"variable\",\"max_children\":2147483647,\"ignore_unmapped\":false}}],\"boost\":1}},\"boost\":1}},\"aggregations\":{\"activities\":{\"children\":{\"type\":\"activity\"},\"aggregations\":{\"incident_activities\":{\"filter\":{\"exists\":{\"field\":\"incidentKey\",\"boost\":1}},\"aggregations\":{\"errorMessages\":{\"terms\":{\"shard_min_doc_count\":0,\"field\":\"errorMessage\",\"size\":10000,\"show_term_doc_count_error\":false,\"min_doc_count\":1,\"order\":[{\"_count\":\"desc\"},{\"_key\":\"asc\"}]},\"aggregations\":{\"activity_to_instances\":{\"parent\":{\"type\":\"activity\"},\"aggregations\":{\"workflowIds\":{\"terms\":{\"shard_min_doc_count\":0,\"field\":\"workflowId\",\"size\":10000,\"show_term_doc_count_error\":false,\"min_doc_count\":1,\"order\":[{\"_count\":\"desc\"},{\"_key\":\"asc\"}]}}}}}}}}}}}}";
			   		JSONObject obj2 = new JSONObject(query2);
			   		
			   		  logger.info("COMPARE");
			   		  logger.info("ORIGINAL:\n" + query);
			   		  logger.info("EXPECTED:\n" + obj1.toString());
	   		    	 if(obj1.toString().equals(query)){
	   		    		 logger.info("Query Matched");
	   		    		 query = obj2.toString();
	   		    	 }
	   		    	 
	   		    	////////////////////////////////////////////////////////////////////////////////////////////
	        	   
		           ByteBuf bufferNew = Unpooled.wrappedBuffer(query.getBytes());
		           BytesReference byteContentNew = Netty4Utils.toBytesReference(bufferNew);
		           request1.setContent(byteContentNew);

	        	   logger.info("\n     QUERY: \n" + query + "\n#############################\n");
	        	   logger.info("************** END **********************");
	        	   
	           }
	
	            originalHandler.handleRequest(request1, channel, client);
	            
	          };
	 }
	
	private boolean filter(RestRequestWrapper p_request) {
		 if (p_request.method().equals(Method.POST) && p_request.content().length() > 1) {
			 String urls[]={
					 "operate-list-view_alias/_search"
					 };  
			for(int i=0; i<urls.length; i++) {
				if(p_request.uri().contains(urls[i])) {
					return true;
				}
			}
		 }
		return false;
	}
}
