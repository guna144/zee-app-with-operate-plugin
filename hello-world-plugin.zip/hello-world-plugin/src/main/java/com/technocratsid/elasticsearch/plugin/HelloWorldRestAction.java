package com.technocratsid.elasticsearch.plugin;

import java.io.IOException;
import java.util.Date;
import java.util.Map.Entry;
import java.util.logging.Logger;

import org.elasticsearch.client.Requests;
import org.elasticsearch.client.node.NodeClient;
import org.elasticsearch.common.bytes.BytesReference;
//import org.elasticsearch.common.bytes.BytesReference;
import org.elasticsearch.common.inject.Inject;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.json.JsonXContent;
import org.elasticsearch.rest.BaseRestHandler;
import org.elasticsearch.rest.BytesRestResponse;
import org.elasticsearch.rest.RestChannel;
import org.elasticsearch.rest.RestController;
import org.elasticsearch.rest.RestHandler;
import org.elasticsearch.rest.RestRequest;
import org.elasticsearch.rest.RestStatus;

public class HelloWorldRestAction extends BaseRestHandler {
	
	private static final Logger logger = Logger.getLogger(HelloWorldRestAction.class.getName());
	
	/*@Inject
    public HelloWorldRestAction(Settings settings, RestController controller) {
        super(settings);
        controller.registerFilter(new RestFilter() {

			@Override
			public void process(RestRequest request, RestChannel channel, NodeClient client, RestFilterChain filterChain)
					throws Exception {
				RestRequest newRequest = new RestRequest(request.params(), request.path()) {
                    @Override
                    public String uri() {
                        logger.info("add customize uri");
                        return request.uri();
                    }

                    @Override
                    public Method method() {
                        logger.info("method shall be the same");
                        return request.method();
                    }

                    @Override
                    public Iterable<Entry<String, String>> headers() {
                        logger.info("add customized header to request");
                        return request.headers();
                    }

                    @Override
                    public String header(String name) {
                        return request.header(name);
                    }

                    @Override
                    public boolean hasContent() {
                        logger.info("has Contect?:" + request.hasContent());
                        return request.hasContent();
                    }

                    @Override
                    public BytesReference content() {
                        logger.info("customized content is called");
                        return request.content();
                    }
                };
                filterChain.continueProcessing(newRequest, channel, client);				
			}});
    }

	@Override
	protected RestChannelConsumer prepareRequest(RestRequest request, NodeClient client) throws IOException {
    	return channel -> {
	      final XContentBuilder builder = JsonXContent.contentBuilder();//channel.newBuilder();
	
	      builder.field("description","This is a sample response: "+ new Date().toString());
	      
	      builder.endObject();
	      
	      logger.info("************************** URI from request :"+request.uri());
	      logger.info("************************** URI from headers values :"+request.headers());
	      builder.startObject().field("message", "Test message from existing rest api....").endObject();
	      channel.sendResponse(new BytesRestResponse(RestStatus.OK, builder));
		};
	}
*/
	
	@Inject
	public HelloWorldRestAction(Settings settings,  RestController restController) {
		super(settings);
//		restController.registerHandler(RestRequest.Method.GET, "/_search",this);
//		restController.registerHandler(RestRequest.Method.POST, "/_search",this);
//		restController.registerHandler(RestRequest.Method.GET, "/{index}/_search", this);
//		restController.registerHandler(RestRequest.Method.POST, "/{index}/_search", this);
	}

	@Override
    public String getName() {
          return "sample_get";
    }

    @Override
    protected RestChannelConsumer prepareRequest(RestRequest request, NodeClient client) throws IOException {
    	
////    	request.uri()
    	final boolean isPretty = request.hasParam("pretty");
    	final String index = request.param("index");
    	return channel -> {
            final XContentBuilder builder = JsonXContent.contentBuilder();//channel.newBuilder();
            
            if(isPretty){
            	builder.prettyPrint().lfAtEnd();
            }
            builder.startObject();
            if(index != null){
            	builder.field("index",index);
            }
            builder.field("description","This is a sample response: "+ new Date().toString());
            
            builder.endObject();
            
            logger.info("************************** URI from request :"+request.uri());
            logger.info("************************** URI from headers values :"+request.getHeaders().values());
////            builder.startArray("queries").field("active",true).field("incidents", true).field("running",true).endObject();
            //builder.startObject().field("message", "Test message from existing rest api....").endObject();
            channel.sendResponse(new BytesRestResponse(RestStatus.OK, builder));
      };
     }
    
   

}
