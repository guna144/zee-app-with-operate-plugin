package com.technocratsid.elasticsearch.plugin;

import java.util.Date;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

public class ModifyJSON {

	public static void main(String[] args) {
		
		String varName = "input1";
		String varValue = "25";
		String input = "{\"size\":0,\"query\":{\"constant_score\":{\"filter\":{\"bool\":{\"must\":[{\"bool\":{\"should\":[{\"bool\":{\"must_not\":[{\"exists\":{\"field\":\"endDate\",\"boost\":1.0}}],\"adjust_pure_negative\":true,\"boost\":1.0}},{\"exists\":{\"field\":\"endDate\",\"boost\":1.0}}],\"adjust_pure_negative\":true,\"boost\":1.0}},{\"terms\":{\"workflowId\":[\"1136025\"],\"boost\":1.0}}],\"adjust_pure_negative\":true,\"boost\":1.0}},\"boost\":1.0}},\"aggregations\":{\"activities\":{\"children\":{\"type\":\"activity\"},\"aggregations\":{\"active_activities\":{\"filter\":{\"bool\":{\"must\":[{\"term\":{\"activityType\":{\"value\":\"END_EVENT\",\"boost\":1.0}}},{\"term\":{\"activityState\":{\"value\":\"COMPLETED\",\"boost\":1.0}}}],\"adjust_pure_negative\":true,\"boost\":1.0}},\"aggregations\":{\"unique_activities\":{\"terms\":{\"field\":\"activityId\",\"size\":10000,\"min_doc_count\":1,\"shard_min_doc_count\":0,\"show_term_doc_count_error\":false,\"order\":[{\"_count\":\"desc\"},{\"_key\":\"asc\"}]},\"aggregations\":{\"activity_to_workflow\":{\"parent\":{\"type\":\"activity\"}}}}}}}}}}";
		String additionalFilter = "{\"has_child\":{\"query\":{\"bool\":{\"must\":[{\"term\":{\"varName\":{\"value\":\""+ varName +"\",\"boost\":1.0}}},{\"term\":{\"varValue\":{\"value\":\""+ varValue +"\",\"boost\":1.0}}}],\"adjust_pure_negative\":true,\"boost\":1.0}},\"type\":\"variable\",\"score_mode\":\"none\",\"min_children\":0,\"max_children\":2147483647,\"ignore_unmapped\":false,\"boost\":1.0}}";
		
		JSONObject jsonObject = null;
		
		Date start = new Date();
				
		try {
			 start = new Date();
		     jsonObject = new JSONObject(input);
		     System.out.println("Parsing: " + (new Date().getTime() - start.getTime()));

		     start = new Date();
		    	 if(jsonObject.has("query"))
			    	 if(jsonObject.getJSONObject("query").has("constant_score"))
			    		 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").has("filter"))
			    			 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").has("bool"))
			    				 if(jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").getJSONObject("bool").has("must")){
			    				 JSONObject jsonNode =  jsonObject.getJSONObject("query").getJSONObject("constant_score").getJSONObject("filter").getJSONObject("bool");
			    				 JSONObject jsonFilterObject = new JSONObject(additionalFilter);
			    				 jsonNode.append("must", jsonFilterObject);
			    				 System.out.println("jsonObject >> :: "+jsonNode);
			    			 }
		      System.out.println("Modifying: " + (new Date().getTime() - start.getTime()));
		      
		}catch (JSONException err){
			System.out.println("Error :: "+err.toString());
		}

		String output = jsonObject.toString();
		
		System.out.println("\nOUTPUT:\n" + output );
				

			
	}

}
