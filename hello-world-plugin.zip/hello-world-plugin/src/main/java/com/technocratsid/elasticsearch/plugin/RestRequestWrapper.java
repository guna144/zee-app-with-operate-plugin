package com.technocratsid.elasticsearch.plugin;

import org.elasticsearch.common.bytes.BytesReference;
import org.elasticsearch.rest.RestRequest;

public class RestRequestWrapper extends RestRequest  {
	
	private RestRequest restRequest;
	private BytesReference content;
	   
	public RestRequestWrapper(RestRequest request) {
		super(request.getXContentRegistry(), request.params(), request.path(), request.getHeaders());
		restRequest = request;
		content = restRequest.content();
    }   
		@Override
		public Method method() {
			return restRequest.method();
		}

		@Override
		public String uri() {
			return restRequest.uri();
		}

		@Override
		public boolean hasContent() {
			return restRequest.hasContent();
		}

		@Override
		protected BytesReference innerContent() {
			return content;
		}
		public BytesReference getContent() {
			return content;
		}
		public void setContent(BytesReference content) {
			this.content = content;
		}
}
