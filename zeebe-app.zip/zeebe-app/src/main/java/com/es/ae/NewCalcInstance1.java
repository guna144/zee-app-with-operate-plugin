package com.es.ae;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.WorkflowInstanceEvent;
import io.zeebe.protocol.ErrorType;
import io.zeebe.protocol.impl.record.value.incident.IncidentRecord;
import io.zeebe.util.buffer.BufferUtil;

public class NewCalcInstance1 {

	public static void main(String[] args) {

		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected.");
	        
            final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
                    .bpmnProcessId("calculation2")
                    .latestVersion()
                    .variables("{\"input1\": 10,\"input2\": 14}") // Create Active Instances change input2 to input4
//                    .variables("{\"input1\": 10,\"input4\": 2}") // Create Instances with Incidents change input2 to input4
                    .send()
                    .join();

            final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();

            System.out.println("Workflow instance created. Key: " + workflowInstanceKey);
            
	        client.close();
	        System.out.println("Closed.");
	}
}
