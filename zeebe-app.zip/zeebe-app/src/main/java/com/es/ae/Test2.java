package com.es.ae;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.events.DeploymentEvent;
import io.zeebe.client.api.events.WorkflowInstanceEvent;

public class Test2 {

	
	// JDBC driver name and database URL 
	   static final String JDBC_DRIVER = "org.h2.Driver";   
	   static final String DB_URL = "jdbc:h2:~/zeebe-monitor;AUTO_SERVER=TRUE";  
	   
	   //  Database credentials 
	   static final String USER = "sa"; 
	   static final String PASS = ""; 
	  
	   
	public static void main(String[] args) {

//		final String broker = "GunaHP:26500";
//
//	    final String bpmnProcessId = "http-example-post-test3";
//	    
//
//	    final ZeebeClientBuilder clientBuilder =
//	        ZeebeClient.newClientBuilder().brokerContactPoint(broker);
//
//	    try (ZeebeClient client = clientBuilder.build()) {
//	    	System.out.println("Stage 1");
//	      final DeploymentEvent deploymentEvent =
//	          client.newDeployCommand().addResourceFromClasspath("http-post.bpmn").send().join();
//	      System.out.println("Stage 2");
//
//	      System.out.println("Deployment created with key: " + deploymentEvent.getKey());
//	    }
//	    
//	    
//	    try (ZeebeClient client = clientBuilder.build()) {
//
//	      System.out.println("Creating workflow instance");
//
//	      final WorkflowInstanceEvent workflowInstanceEvent =
//	          client
//	              .newCreateInstanceCommand()
//	              .bpmnProcessId(bpmnProcessId)
//	              .latestVersion()
//	              .send()
//	              .join();
//
//	      System.out.println(
//	          "Workflow instance created with key: " + workflowInstanceEvent.getWorkflowInstanceKey());
//	    }
		
		
		Connection conn = null; 
	      Statement stmt = null; 
	      try { 
	         // STEP 1: Register JDBC driver 
	         Class.forName(JDBC_DRIVER); 
	             
	         //STEP 2: Open a connection 
	         System.out.println("Connecting to database..."); 
	         conn = DriverManager.getConnection(DB_URL,USER,PASS);  
	         System.out.println("Connection object : "+conn); 
	         // STEP 3: Execute a query 
	         System.out.println("Connected database successfully..."); 
	         stmt = conn.createStatement(); 
	         String sql = "SELECT * FROM workflow"; 
	         ResultSet rs = stmt.executeQuery(sql); 
//	         System.out.print("Size: " + rs.getFetchSize()); 
	         // STEP 4: Extract data from result set 
	         while(rs.next()) { 
	            
	            
	            // Display values 
	            
	            System.out.print(", BPMN PROCESS ID: " + rs.getString("BPMN_PROCESS_ID_")); 
//	            System.out.print(", First: " + rs.getInt(3)); 
//	            System.out.println(", Last: " + rs.getInt(4)); 
	         } 
	         // STEP 5: Clean-up environment 
	         conn.close(); 
	      } catch(SQLException se) { 
	         //Handle errors for JDBC 
	         se.printStackTrace(); 
	      } catch(Exception e) { 
	         //Handle errors for Class.forName 
	         e.printStackTrace(); 
	      } finally { 
	         //finally block used to close resources 
	         try{ 
	            if(stmt!=null) stmt.close(); 
	         } catch(SQLException se2) { 
	         } // nothing we can do 
	         try { 
	            if(conn!=null) conn.close(); 
	         } catch(SQLException se){ 
	            se.printStackTrace(); 
	         } //end finally try 
	      } //end try 
		
	}

}
