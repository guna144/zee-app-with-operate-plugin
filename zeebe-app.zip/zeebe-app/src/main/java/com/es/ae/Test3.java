package com.es.ae;

import java.util.Map;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.DeploymentEvent;
import io.zeebe.client.api.events.WorkflowInstanceEvent;
import io.zeebe.client.api.subscription.JobWorker;

public class Test3 {

	public static void main(String[] args) {

		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected.");
	        
//	        final DeploymentEvent deployment = client.newDeployCommand()
//	                .addResourceFromClasspath("http-post.bpmn")
//	                .send()
//	                .join();
//
//            final int version = deployment.getWorkflows().get(0).getVersion();
//            System.out.println("Workflow deployed. Version: " + version);
//            
//            final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
//                    .bpmnProcessId("http-example-post-test3")
//                    .latestVersion()
//                    .variables("{\"input1\": 4,\"input2\": 3}")
//                    .send()
//                    .join();
//
//            final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();
//
//            System.out.println("Workflow instance created. Key: " + workflowInstanceKey);

            final JobWorker jobWorker = client.newWorker()
                    .jobType("http-service")
                    .handler((jobClient, job) ->
                    {
                    	final Map<String, Object> variables = job.getVariablesAsMap();
//                    	job.getHeaders().getElementInstanceKey()
                    	
//                    	client.newSetVariablesCommand(incident.getElementInstanceKey())
//                        .variables(NEW_PAYLOAD)
//                        .send()
//                        .join();
//
//                    client.newUpdateRetriesCommand(incident.getJobKey())
//                        .retries(3)
//                        .send()
//                        .join();
//
//                    client.newResolveIncidentCommand(incident.getKey())
//                        .send()
//                        .join();        
                        System.out.println("Process order: " + variables.get("sourceValue"));
                        System.out.println("Collect money");


                        String result = null;
                        result = "{\"sourceValue\": \"Ok\"}";

                        jobClient.newCompleteCommand(job.getKey())
                            .variables(result)
                            .send()
                            .join();
                    })
                    .fetchVariables("sourceValue")
                    .open();

                // waiting for the jobs

                jobWorker.close();
            
	        client.close();
	        System.out.println("Closed.");
	}

}
