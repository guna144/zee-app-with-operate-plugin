package com.es.ae;

import java.time.Duration;
import java.util.Scanner;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;

public class Test4 {

	public static void main(String[] args) {
		
		
		final String broker = "127.0.0.1:26500";

	    final String jobType = "http-service";

	    final ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(broker);

	    try (ZeebeClient client = builder.build()) {

	      System.out.println("Opening job worker.");

	      final JobWorker workerRegistration =
	          client
	              .newWorker()
	              .jobType(jobType)
	              .handler(new ExampleJobHandler())
	              .timeout(Duration.ofSeconds(10))
	              .open();

	      System.out.println("Job worker opened and receiving jobs.");

	      // call workerRegistration.close() to close it

	      // run until System.in receives exit command
	      waitUntilSystemInput("exit");
	    }
	  }

	  private static class ExampleJobHandler implements JobHandler {
	    @Override
	    public void handle(final JobClient client, final ActivatedJob job) {
	      // here: business logic that is executed with every job
	      System.out.println(
	          String.format(
	              "[type: %s, key: %s, lockExpirationTime: %s]\n[headers: %s]\n[variables: %s]\n===",
	              job.getType(),
	              job.getKey(),
	              job.getDeadline().toString(),
	              job.getHeaders(),
	              job.getVariables()));

	      client.newCompleteCommand(job.getKey()).send().join();
	    }
	  }

	  private static void waitUntilSystemInput(final String exitCode) {
	    try (Scanner scanner = new Scanner(System.in)) {
	      while (scanner.hasNextLine()) {
	        final String nextLine = scanner.nextLine();
	        if (nextLine.contains(exitCode)) {
	          return;
	        }
	      }
	    }
	  }
		

	}

