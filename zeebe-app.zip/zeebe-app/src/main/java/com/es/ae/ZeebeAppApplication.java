package com.es.ae;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.DeploymentEvent;
import io.zeebe.client.api.events.WorkflowInstanceEvent;
import io.zeebe.client.api.subscription.JobWorker;

@SpringBootApplication
public class ZeebeAppApplication {

	public static void main(String[] args) {
//		SpringApplication.run(ZeebeAppApplication.class, args);
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected : "+client);
	        
	        
	        final DeploymentEvent deployment = client.newDeployCommand()
	                .addResourceFromClasspath("http-post.bpmn")
	                .send()
	                .join();

	            final int version = deployment.getWorkflows().get(0).getVersion();
	            System.out.println("Workflow deployed. Version: " + version);
	            
	            
//	            final Map<String, Object> data = new HashMap<>();
//	            data.put("input1", 3);
//	            data.put("input2", 6);
	            
	            final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
	                    .bpmnProcessId("http-example-post")
	                    .latestVersion()
	                    .send()
	                    .join();

	                final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();

	                System.out.println("Workflow instance created. Key: " + workflowInstanceKey);
	                
	                final JobWorker jobWorker = client.newWorker()
	                        .jobType("http-service")
	                        .handler((jobClient, job) ->
	                        {
	                            System.out.println("Test Ok");

	                            jobClient.newCompleteCommand(job.getKey()).send().join();
	                        })
	                        .open();

	                    // waiting for the jobs

	                    jobWorker.close();
	           // waitUntilClose();

//	            client.close();
	            System.out.println("Closed.");
	          }

}
