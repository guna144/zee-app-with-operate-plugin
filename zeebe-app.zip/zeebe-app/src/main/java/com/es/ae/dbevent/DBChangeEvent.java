package com.es.ae.dbevent;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.es.ae.dbevent.model.DataModel;

import io.zeebe.client.ZeebeClient;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleDriver;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.dcn.RowChangeDescription;


public class DBChangeEvent  {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.print("Welcome");
//	}
	
	static final String USERNAME = "system";
    static final String PASSWORD = "admin12345";
    static String URL = "jdbc:oracle:thin:@172.32.168.52:1521:xe";
     
    public static void main(String[] args) {
    	DBChangeEvent oracleDCN = new DBChangeEvent();
        try {
             oracleDCN.run();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

	
    private void run() throws Exception{
        OracleConnection conn = connect();
        Properties prop = new Properties();
        prop.setProperty(OracleConnection.DCN_NOTIFY_ROWIDS, "true");
        DatabaseChangeRegistration dcr = conn.registerDatabaseChangeNotification(prop);
         
        try{
            dcr.addListener(new DatabaseChangeListener() {
 
                public void onDatabaseChangeNotification(DatabaseChangeEvent dce) {
                	
                	RowChangeDescription[] rowsChanged = dce.getTableChangeDescription()[0].getRowChangeDescription();
                    String rowId = null;
                    List<DataModel> dataCollection = new ArrayList<DataModel>();
                    System.out.println("************************** DataBase operation done! ********************* "+rowsChanged.length);
                    int recordCount = rowsChanged.length;
                    
                	for(RowChangeDescription  row : rowsChanged) {
          
//                		
                		rowId = row.getRowid().stringValue();
	                    System.out.println("Changed row id : "+rowId);
	                    System.out.println("Row operation : "+row.getRowOperation().toString());
	                    
	                    //synchronized(this) {
		                    try {
					            Statement stmt = conn.createStatement();
					            ((OracleStatement) stmt).setDatabaseChangeRegistration(dcr);
					            ResultSet rs = stmt.executeQuery("select * from subreq_status_tbl where rowid='"+rowId+"'");
					            DataModel data = new DataModel();
					            
					            while (rs.next()) {
					            	data.setSubRequestId(rs.getString("SUBREQUEST_ID"));
					            	data.setStatus(rs.getString("STATUS"));
					            	dataCollection.add(data);
					            	System.out.println(dataCollection);
					            }
					            rs.close();
					            stmt.close();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
	                   // }
		                    
		                    if(dataCollection != null && dataCollection.size() == recordCount) {
		                    	for(DataModel data : dataCollection){
		                    		System.out.println("Database Change Triggered");

			                    	System.out.println("Start");
			                        	String status = data.getStatus();
			                        	String subRequestId = data.getSubRequestId();
			                        	
			                        	switch(status) 
			                            { 
			                                case "87": 
			                                	SubReq_Opened_Event(subRequestId);
			                                    break; 
			                                case "88": 
			                                	SubReq_ToBeProcess_Event(subRequestId);
			                                    break; 
			                                case "89": 
			                                	SubReq_InProgress_Event(subRequestId);
			                                    break; 
			                                case "49464": 
			                                	SubReq_ComsInProgress_Event(subRequestId);
			                                    break;
			                                case "90": 
			                                	SubReq_Closed_Event(subRequestId);
			                                    break;
			                                default: 
			                                	Raise_Incident_Event();
			                            }
			                        	System.out.println("End");
		                    	}
		                	}
                	}// for loop end
                }
            });
             
            Statement stmt = conn.createStatement();
            ((OracleStatement) stmt).setDatabaseChangeRegistration(dcr);
            ResultSet rs = stmt.executeQuery("select * from subreq_status_tbl where rownum=1");
            while (rs.next()) {
            }
            rs.close();
            stmt.close();
        }catch(SQLException ex){
            if (conn != null)
            {
                conn.unregisterDatabaseChangeNotification(dcr);
                conn.close();
            }
            throw ex;
        }
    }
 
    OracleConnection connect() throws SQLException {
        OracleDriver dr = new OracleDriver();
        Properties prop = new Properties();
        prop.setProperty("user", DBChangeEvent.USERNAME);
        prop.setProperty("password", DBChangeEvent.PASSWORD);
        return (OracleConnection) dr.connect(DBChangeEvent.URL, prop);
    }
    
    
    
    private void SubReq_Opened_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected...... Status 87");
            client.newPublishMessageCommand()
            		.messageName("MSG_SUBREQ_OPENED")
            		.correlationKey("")
            		.variables("{\"output-1\": 3, \"output-2\": 4,"
            				+ " \"KEY_SUBREQ_PROCESSING_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_INPRO_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_COMS_ID\": "+subRequestId+","
            				+ " \"KEY_SUBREQ_CLOSED_ID\": "+subRequestId+","
            				+ " \"KEY_RAISE_INCIDENT\": "+subRequestId+"}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
    }
    
    private void SubReq_ToBeProcess_Event(String subRequestId){
    	
    	final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected....... Status 88");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_PROCESSING")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();


	        client.close();
	        System.out.println("Closed.");
    }

	private void SubReq_InProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 89");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_INPROGRESS")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void SubReq_ComsInProgress_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 49464");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_COMS_INP")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	
	private void SubReq_Closed_Event(String subRequestId){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected...... Status 90");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_SUBREQ_CLOSED")
		    		.correlationKey(subRequestId) 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
	
	        client.close();
	        System.out.println("Closed.");
	}
	
	private void Raise_Incident_Event(){
		
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();
	
	        System.out.println("Connected....... Status others");
	        client.newPublishMessageCommand()
		    		.messageName("MSG_RAISE_INCIDENT")
		    		.correlationKey("input-1001") 
		    		.timeToLive(Duration.ofMinutes(1))
		    		.send()
		    		.join();
	
//	        client.newFailCommand(2)
	
	        client.close();
	        System.out.println("Closed.");
	        
	        
	        
	}
	
	
//	 public boolean rejectIncidentCreation(
//		      IncidentRecord incidentEvent, CommandControl<IncidentRecord> commandControl) {
//		    final IncidentState incidentState = zeebeState.getIncidentState();
//
//		    final boolean isJobIncident = incidentState.isJobIncident(incidentEvent);
//
//		    if (isJobIncident) {
//		      return rejectJobIncident(incidentEvent.getJobKey(), commandControl);
//		    } else {
//		      return rejectWorkflowInstanceIncident(incidentEvent.getElementInstanceKey(), commandControl);
//		    }
//		  }
//	 
//	 public void createIncident(long incidentKey, IncidentRecord incident) {
//		    zeebeDb.transaction(
//		        () -> {
//		          this.incidentKey.wrapLong(incidentKey);
//		          this.incidentRecordToWrite.wrapObject(incident);
//		          incidentColumnFamily.put(this.incidentKey, this.incidentRecordToWrite);
//
//		          if (isJobIncident(incident)) {
//		            jobKey.wrapLong(incident.getJobKey());
//		            jobIncidentColumnFamily.put(jobKey, this.incidentKey);
//		          } else {
//		            elementInstanceKey.wrapLong(incident.getElementInstanceKey());
//		            workflowInstanceIncidentColumnFamily.put(elementInstanceKey, this.incidentKey);
//		          }
//		        });
//		  }
}
