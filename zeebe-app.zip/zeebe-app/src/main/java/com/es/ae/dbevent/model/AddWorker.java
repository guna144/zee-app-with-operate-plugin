package com.es.ae.dbevent.model;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Logger;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;

public class AddWorker {

	static Logger LOGGER = Logger.getLogger(AddWorker.class.getName());
	
	
	public static void main(String[] args) {
		
		final String broker = "127.0.0.1:26500";

	    final String jobType = "operation-add";
	    
	    final String jobType2 = "operation-multiply";

	    final ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(broker);

	    try (ZeebeClient client = builder.build()) {

	    	LOGGER.info("Opening job worker.");
	      
	    	LOGGER.info("Job Name :: "+client.getConfiguration().getDefaultJobWorkerName());
	      
	      

	      final JobWorker workerRegistration =
	          client
	              .newWorker()
	              .jobType(jobType)
	              .handler(new ExampleJobHandler1())
	              .timeout(Duration.ofSeconds(10))
	              .open();

	      
	      final JobWorker workerRegistration2 =
		          client
		              .newWorker()
		              .jobType(jobType2)
		              .handler(new ExampleJobHandler2())
		              .timeout(Duration.ofSeconds(10))
		              .open();
	      
	      LOGGER.info("Job worker opened and receiving jobs.");

	      // call workerRegistration.close() to close it

	      // run until System.in receives exit command
	      waitUntilSystemInput("exit");
	    }
	    
	    
	    
	  }

	  private static class ExampleJobHandler1 implements JobHandler {
	    @Override
	    public void handle(final JobClient client, final ActivatedJob job) {
	    LOGGER.info("######################### OPERATION: ADD");
	    
	    final Map<String, Object> inputVariables = job.getVariablesAsMap();
	    final Map<String, Object> outputVariables = new HashMap<>();
	    	
	    Integer input1 = (Integer) inputVariables.get("input1");
	    LOGGER.info("######################### INPUT1: " + input1);
	    
	    Integer input2 = (Integer) inputVariables.get("input2");
	    LOGGER.info("######################### INPUT2: " + input2);
	    
	    Integer result = Integer.sum(input1, input2);
	    
	    LOGGER.info("######################### RESULT: " + result);
	    
	    outputVariables.put("output1", result);
	    	
//	      LOGGER.info(
//	          String.format(
//	              "[type: %s, key: %s, lockExpirationTime: %s]\n[headers: %s]\n[variables: %s]\n===",
//	              job.getType(),
//	              job.getKey(),
//	              job.getDeadline().toString(),
//	              job.getHeaders(),
//	              job.getVariables()));

	    	client
	        .newCompleteCommand(job.getKey())
	        .variables(outputVariables)
	        .send()
	        .join();
	    }
	  }
	  
	  private static class ExampleJobHandler2 implements JobHandler {
		    @Override
		    public void handle(final JobClient client, final ActivatedJob job) {
		    LOGGER.info("######################### OPERATION: MULTIPLY");
		    
		    final Map<String, Object> inputVariables = job.getVariablesAsMap();
		    final Map<String, Object> outputVariables = new HashMap<>();
		    	
		    Integer input1 = (Integer) inputVariables.get("input1");
		    LOGGER.info("######################### INPUT1: " + input1);
		    
		    Integer input2 = (Integer) inputVariables.get("input2");
		    LOGGER.info("######################### INPUT2: " + input2);
		    
		    Integer result = input1 * input2;
		    
		    LOGGER.info("######################### RESULT: " + result);
		    
		    outputVariables.put("output2", result);
		    	
//		      LOGGER.info(
//		          String.format(
//		              "[type: %s, key: %s, lockExpirationTime: %s]\n[headers: %s]\n[variables: %s]\n===",
//		              job.getType(),
//		              job.getKey(),
//		              job.getDeadline().toString(),
//		              job.getHeaders(),
//		              job.getVariables()));

		    	client
		        .newCompleteCommand(job.getKey())
		        .variables(outputVariables)
		        .send()
		        .join();
		    }
		  }

	  private static void waitUntilSystemInput(final String exitCode) {
	    try (Scanner scanner = new Scanner(System.in)) {
	      while (scanner.hasNextLine()) {
	        final String nextLine = scanner.nextLine();
	        if (nextLine.contains(exitCode)) {
	          return;
	        }
	      }
	    }
	  }
	}

