/**
 * 
 */
package com.es.ae.event;

import java.time.Duration;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.WorkflowInstanceEvent;

/**
 * @author Guna Palani
 *
 */
public class EventTrigger {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected.");
	        
            client.newPublishMessageCommand()
            		.messageName("Message-Event")//.messageName("input3-message")
            		.correlationKey("input-123") // .correlationKey("input-123")
            		.timeToLive(Duration.ofMinutes(1))
            		.variables("{\"input3\": 4}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
		
	}

}
