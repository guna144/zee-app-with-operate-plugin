/**
 * 
 */
package com.es.ae.event;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.assertj.core.api.Assertions;

import io.zeebe.broker.incident.processor.IncidentState;
import io.zeebe.broker.logstreams.state.ZeebeState;
import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;
import io.zeebe.protocol.ErrorType;
import io.zeebe.protocol.impl.record.value.incident.IncidentRecord;
import io.zeebe.util.buffer.BufferUtil;
import scala.util.control.Exception;

/**
 * @author Guna Palani
 *
 */
public class MultiplyWorker {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		final String broker = "127.0.0.1:26500";

	    final String jobType = "operation-multiply";
	    
	    final ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(broker);

	    try( ZeebeClient client = builder.build()) {
	   

	      System.out.println("Opening job worker.");
	      
	      final JobWorker workerRegistration =
	          client
	              .newWorker()
	              .jobType(jobType)
	              .handler(new ExampleJobHandler())
	              .timeout(Duration.ofSeconds(10))
	              .open();
	
	      System.out.println("Job worker opened and receiving jobs.");

	      waitUntilSystemInput("exit");
	    }
	  }
	 
	  private static class ExampleJobHandler implements JobHandler {
	    @Override
	    public void handle(final JobClient client, final ActivatedJob job)   {
	    System.out.println("######################### OPERATION:");
	    
	    final Map<String, Object> inputVariables = job.getVariablesAsMap();
	    final Map<String, Object> outputVariables = new HashMap<>();
	    	
	    Integer output1 = (Integer) inputVariables.get("output1");
	    System.out.println("######################### INPUT1: " + output1);
	    
	    Integer input3 = (Integer) inputVariables.get("input3");
	    System.out.println("######################### INPUT2: " + input3);
	    
	    Integer result = output1 * input3;
	    
	    System.out.println("######################### RESULT: " + result);
	    
	    
	    outputVariables.put("result", result);
	    
//	    client.newFailCommand(job.getKey()).retries(1).errorMessage("test123456789").send().join();
	    
	    client.newCompleteCommand(job.getKey())
		        .variables(outputVariables)
		        .send()
		        .join();
	    }
	 }

	  private static void waitUntilSystemInput(final String exitCode) {
	    try (Scanner scanner = new Scanner(System.in)) {
	      while (scanner.hasNextLine()) {
	        final String nextLine = scanner.nextLine();
	        if (nextLine.contains(exitCode)) {
	          return;
	        }
	      }
	    }
	  }

}
