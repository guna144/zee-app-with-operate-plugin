/**
 * 
 */
package com.es.ae.event;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.WorkflowInstanceEvent;

/**
 * @author Guna Palani
 *
 */
public class NewInstance1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected.");
	        
            final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
                    .bpmnProcessId("EventTrigger1")
                    .latestVersion()
                    .variables("{\"input1\": 5,\"input2\": 5, \"inputID\": \"input-123\"}")
                    .send()
                    .join();

            
            final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();

            System.out.println("Workflow instance created. Key: " + workflowInstanceKey);

	        client.close();
	        System.out.println("Closed.");
	}

}
