/**
 * 
 */
package com.es.ae.event;

import java.time.Duration;

import io.zeebe.client.ZeebeClient;

/**
 * @author Guna Palani
 *
 */
public class StartEventMsg {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		final ZeebeClient client = ZeebeClient.newClientBuilder()
	            // change the contact point if needed
	            .brokerContactPoint("GunaHP:26500")
	            .build();

	        System.out.println("Connected.");
            client.newPublishMessageCommand()
            		.messageName("Start-Event-Message")
            		.correlationKey("")
            		.variables("{\"output-1\": 3, \"output-2\": 4,  \"inputID\": \"input-123\"}")
            		.send()
            		.join();


	        client.close();
	        System.out.println("Closed.");
	}

}
